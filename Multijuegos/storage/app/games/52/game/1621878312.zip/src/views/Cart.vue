<template>
  <div id="cart">
    <h1>Cart</h1>
    <div class="container-md">
      <p>You have <strong>N</strong> products in your cart.</p>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
export default {
  name: 'Cart'
}
</script>